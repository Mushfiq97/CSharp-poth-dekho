﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Poth_Dekho
{
    public partial class tour_guide_profile_details : Form
    {
        public tour_guide_profile_details()
        {
            InitializeComponent();
        }
    }
}
